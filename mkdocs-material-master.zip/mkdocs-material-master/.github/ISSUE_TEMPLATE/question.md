---
name: Question
about: The issue tracker is not for questions. Please ask your question on StackOverflow.
title: ''
labels: ''
assignees: ''

---

__THE ISSUE TRACKER IS NOT FOR QUESTIONS.__  
__DO NOT CREATE A NEW ISSUE TO ASK A QUESTION.__

Please use [StackOverflow][1] to ask your question. If the question is theme-related, you may also use the [official Gitter channel][2]. Issues that
only contain questions will be deleted.

  [1]: https://stackoverflow.com
  [2]: https://gitter.im/squidfunk/mkdocs-material
